### Prerequisites

Install Python 3.7.4 and run:

> pip install numpy matplotlib sklearn pandas

### Run Application

> python mosaic_application2.py courses.csv students.csv tests.csv marks.csv output.json

### Rubric (Self-Assessment)

1. Correctness:
	Considered all possible test cases that .py file would be measured against
	Handles improper file inputs
	Provides README file to show how to deploy application (bonus requirement & stretch goals)
2. Code Organization, Readability, and Maintainability
	Consistent design pattern, well-organized, and easy to extend
	Take into account future features (new files, more columns for existing files...)
	Code has proper indentation, vertical spacing, names constants, big picture comments, and meaningful variable names.
	Small amounts of repeated code.
	Use of classes and Objects.
3. Code Performance - Efficiency, Data Structures & Algorithms
	Avoids unnecessary 'for loops' and uses appropriate data structures and algorithms.
	Code is efficient and reduced.
	Implement additional code performance - not integrating extra features as this is a single-purpose application
		(to output JSON for input files).
4. Best Practices & Proficiency in Language/Framework
	Demonstrate a good grasp of Jupyter Notebooks and Python scripts.
	Not using a framework.
5. Completion Speed
	Took an extension due to other commitments and desire to improve the solution as much as possible.
	

