#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sklearn
import sys
import fileinput
import json


# Define Classes, Create Class Objects, Format for JSON File Objects
class courses(dict):
    # data members
    id = None
    name = None
    teacher = None
    courseAverage = None

    def __init__(self, id, name, teacher, courseAverage):
        dict.__init__(self, id=id, name=name, teacher=teacher, courseAverage=courseAverage)

class students(dict):
    def __init__(self, id, name, totalAverage, courses):
        dict.__init__(self, id=id, name=name, totalAverage=totalAverage, courses=courses)

class studentArray(dict):
      def __init__(self,students):
        dict.__init__(self, students=students)

class Error(dict):
    def __init__(self, error):
        dict.__init__(self,error=error)

class StopExecution(Exception):
    def _render_traceback_(self):
        pass

def InvalidInput(errorStr):
    error = Error(errorStr)
    errorJSON = json.dumps(error, sort_keys=True, indent=4)
    print(errorJSON)


# In[2]:


course_file = str(sys.argv[1])
courses_df = pd.read_csv(course_file)
courses_df

if not {'id', 'name', 'teacher'}.issubset(courses_df.columns):
    InvalidInput("courses.csv has incorrect or missing data columns!")
    StopExecution()


# In[3]:

students_file = str(sys.argv[2])
students_df = pd.read_csv(students_file)
students_df

if not {'id', 'name'}.issubset(students_df.columns):
    InvalidInput("students.csv has incorrect or missing data columns!")
    StopExecution()

# In[4]:


# Test ID, Course ID, and Test Weightage

tests_file = str(sys.argv[3])
tests_df = pd.read_csv(tests_file)
tests_df

if not {'id', 'course_id', 'weight'}.issubset(tests_df.columns):
    InvalidInput("tests.csv has incorrect or missing data columns!")
    StopExecution()

# In[5]:


# Test ID, Student ID, and Test Marks

marks_file = str(sys.argv[4])
marks_df = pd.read_csv(marks_file)
marks_df

if not {'test_id', 'student_id', 'mark'}.issubset(marks_df.columns):
    InvalidInput("marks.csv has incorrect or missing data columns!")
    StopExecution()

# In[6]:


# Extend tests_df with Course Information

tests_df['name'] = None
tests_df['teacher'] = None

# loop through each row of tests_df
for testsRow in range(len(tests_df.values)):

    # loop through each row of courses_df
    for coursesRow in range(len(courses_df)):

        # course_id in tests.csv corresponds to id in courses.csv
        if tests_df.course_id[testsRow] == courses_df.id[coursesRow]:

            # populate columns of tests_df with items from courses_df
            tests_df.name[testsRow] = courses_df.name[coursesRow]
            tests_df.teacher[testsRow] = courses_df.teacher[coursesRow]

tests_df


# In[7]:


# Extend marks_df with Course, Student and Test information

marks_df['course_id'] = None
marks_df['weight'] = None
marks_df['name'] = None
marks_df['teacher'] = None
marks_df['student_name']= None
marks_df['courseAverage'] = None
marks_df['totalAverage'] = None


# In[8]:


# Generate Combined DataFrame Containing Marks, Tests, and Student Information

# loop through each row of marks_df
for marksRow in range(len(marks_df.values)):

    # loop through each row of tests_df
    for testsRow in range(len(tests_df.values)):

        # test_id in marks.csv corresponds to id in tests.csv
        if marks_df.test_id[marksRow] == tests_df.id[testsRow]:

           # populate columns of marks_df with items from tests_df
            marks_df.course_id[marksRow] = tests_df.course_id[testsRow]
            marks_df.weight[marksRow] = tests_df.weight[testsRow]
            marks_df.name[marksRow] = tests_df.name[testsRow]
            marks_df.teacher[marksRow] = tests_df.teacher[testsRow]

    # loop through each row of students_df
    for studentsRow in range(len(students_df.values)):

        # student_id in marks.csv corresponds to id in students.csv
        if marks_df.student_id[marksRow] == students_df.id[studentsRow]:

            # populate columns of marks_df with items from students_df
            marks_df.student_name[marksRow] = students_df.name[studentsRow]
            continue

marks_df


# In[12]:


# structure which stores successive pairs of marks and weights
#     purpose: to help computer course averages
#
#     key:   (student_id, course_id)
#     value: array[(mark1, weight1), (mark2, weight2) ... ]
student_grades_table = {}

# structure which stores running total course average for each student
#     purpose: to populate totalAverage column of output
#
#     key:   student_id
#     value: sum(student's course averages)
total_avg_mark = {}

# initialize structures
for index,row in list(marks_df.filter(items=['student_id', 'course_id']).iterrows()):
    total_avg_mark[row['student_id']] = 0
    student_grades_table[(row['student_id'],row['course_id'])] = [0,0]

# populate student_grades_table with successive marks and weights
subset_df = marks_df.filter(items=['student_id', 'course_id', 'mark', 'weight'])
for row in subset_df.values:
    student_grades_table[(row[0], row[1])] += [row[2], row[3]]

# used to identify transition from one student_id to another
num_rows = 0
prev_student_id = ""

# loop through each key,value pair
for k,v in student_grades_table.items():
    student_id = k[0]
    course_id = k[1]
    weight_total = 0

    # compute average mark for student in course
    course_avg_mark = 0
    for i in range(0, len(v), 2):
        mark = v[i]
        weight = v[i+1]
        weight_total += weight
        course_avg_mark += mark * weight/100

    # if weights for a course do not add up to 100, raise error
    if weight_total != 100:
        errorStr = "Invalid course weights"
        error = Error(errorStr)
        errorJSON = json.dumps(error, sort_keys=True, indent=4)
        print(errorJSON)

        # Encode into JSON formatted Data
        f = open("zara_output.json", "w")
        f.write(errorJSON)
        f.close()

        raise StopExecution

    # reset the row counter
    if student_id != prev_student_id:
        num_rows = 0
        prev_student_id = student_id

    # compute student's total_avg_mark
    total_avg_mark[student_id] += course_avg_mark
    num_rows += 1

    # add total_avg_mark and course_avg_mark into the marks_df table
    for index,row in list(subset_df.filter(items=['student_id', 'course_id']).iterrows()):

        if (student_id == row['student_id']):
            marks_df.totalAverage[index] = total_avg_mark[student_id]/num_rows

            if (course_id == row['course_id']):
                marks_df.courseAverage[index] = course_avg_mark

marks_df


# In[13]:


studentsArray = []
courses_table = marks_df.filter(items=['course_id', 'name', 'teacher']).drop_duplicates()
students_table = marks_df.filter(items=['student_id', 'student_name', 'totalAverage']).drop_duplicates()
courseAverages_table = marks_df.filter(items=['student_id', 'course_id', 'courseAverage']).drop_duplicates()
course_enrolled_table = marks_df.filter(items=['student_id', 'name']).drop_duplicates()

for studentIndex,studentRow in list(students_table.iterrows()):

    coursesArray = []
    for courseIndex,courseRow in list(courses_table.iterrows()):

        # special case since courseAverage is unique to each course taken by each student
        course_average = 0
        is_enrolled = False
        for row in courseAverages_table.itertuples(index=False):
            if row.student_id == studentRow['student_id'] and row.course_id == courseRow['course_id']:
                course_average = row.courseAverage
                is_enrolled = True

        if is_enrolled == True:
            course = courses(round(float(courseRow['course_id'])), courseRow['name'], courseRow['teacher'].lstrip(), round(course_average,2))
            coursesArray.append(course)

    student = students(round(float(studentRow['student_id'])), studentRow['student_name'], round(studentRow['totalAverage'],2), coursesArray)
    studentsArray.append(student)

# create studentArray object
studentArray = studentArray(studentsArray)

# Encode into JSON formatted Data
studentsJSON = json.dumps(studentArray, sort_keys=False, indent=4)
print(studentsJSON)

f = open("zara_output.json", "w")
f.write(studentsJSON)
f.close()

